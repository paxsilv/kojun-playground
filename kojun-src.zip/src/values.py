from src.error import KojunRuntimeError


class KojunArray:
    def __init__(self, elements, token):
        self.elements = elements
        self.token = token

    def __getitem__(self, index):
        if not isinstance(index, int):
            raise KojunRuntimeError(self.token, "Array index must be an integer.")
        if index < 0 or index >= len(self.elements):
            raise KojunRuntimeError(self.token, f"Array index {index} out of bounds.")
        return self.elements[index]

    def __len__(self):
        return len(self.elements)

    def __repr__(self):
        from src.callables import stringify

        return f"[{', '.join(map(stringify, self.elements))}]"
