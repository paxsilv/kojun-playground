from src.environment import Environment
from src.error import KojunFunctionError
from src.values import KojunArray


class KojunFunction:
    def __init__(self, declaration, closure):
        self._declaration = declaration
        self._closure = closure

    def call(self, interpreter, arguments):
        environment = Environment(self._closure)
        params = self._declaration.params
        variadic = getattr(self._declaration, "variadic", False)
        rest_param = getattr(self._declaration, "rest_param", None)
        # Bind regular parameters
        for i in range(len(params)):
            environment.define(
                params[i].lexeme, arguments[i] if i < len(arguments) else None
            )
        # Bind variadic parameter if present
        if variadic and rest_param is not None:
            rest_args = arguments[len(params) :] if len(arguments) > len(params) else []
            environment.define(rest_param.lexeme, KojunArray(rest_args, rest_param))
        elif len(arguments) > len(params):
            raise KojunFunctionError(
                self._declaration.name.lexeme if self._declaration.name else "<lambda>",
                f"Expected {len(params)} arguments but got {len(arguments)}.",
            )
        try:
            interpreter.execute_block(self._declaration.body, environment)
        except Return as return_value:
            return return_value.value

    def arity(self):
        # For variadic functions, return None to indicate flexible arity
        if getattr(self._declaration, "variadic", False):
            return None
        return len(self._declaration.params)

    def __str__(self):
        declaration_name = "<lambda>"
        if self._declaration.name is not None:
            declaration_name = self._declaration.name.lexeme
        return f"<function {declaration_name}>"


class Return(Exception):
    def __init__(self, value):
        super().__init__()
        self.value = value


class NativeFunctionDisplay:
    def __init__(self):
        self.name: str = "display"

    def call(self, interpreter, arguments):
        print(stringify(arguments[0]), end="")

    def arity(self):
        return 1

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionRead:
    def __init__(self):
        self.name: str = "read"

    def call(self, interpreter, arguments):
        try:
            return input()
        except EOFError:
            return ""

    def arity(self):
        return 0

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionNewline:
    def __init__(self):
        self.name: str = "newline"

    def call(self, interpreter, arguments):
        print()

    def arity(self):
        return 0

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionToNumber:
    def __init__(self):
        self.name: str = "to_number"

    def call(self, interpreter, arguments):
        obj = arguments[0]
        if isinstance(obj, float):
            return obj
        try:
            return float(obj)
        except (ValueError, TypeError):
            raise KojunFunctionError(
                self.name, f"Cannot convert '{stringify(obj)}' to number"
            )

    def arity(self):
        return 1

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionToString:
    def __init__(self):
        self.name: str = "to_string"

    def call(self, interpreter, arguments):
        obj = arguments[0]
        return stringify(obj)

    def arity(self):
        return 1

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionType:
    def __init__(self):
        self.name: str = "type"

    def call(self, interpreter, arguments):
        obj = arguments[0]
        if obj is None:
            return "nil"
        if isinstance(obj, bool):
            return "boolean"
        if isinstance(obj, float):
            return "number"
        if isinstance(obj, str):
            return "string"
        if isinstance(
            obj,
            (
                KojunFunction,
                NativeFunctionDisplay,
                NativeFunctionRead,
                NativeFunctionNewline,
                NativeFunctionToNumber,
                NativeFunctionToString,
                NativeFunctionType,
                NativeFunctionApply,
                NativeFunctionArray,
                NativeFunctionLength,
            ),
        ):
            return "function"
        return "unknown"

    def arity(self):
        return 1

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionApply:
    def __init__(self):
        self.name: str = "apply"

    def call(self, interpreter, arguments):
        if len(arguments) != 2:
            raise KojunFunctionError(
                self.name, f"Expected 2 arguments but got {len(arguments)}."
            )
        func, arglist = arguments
        # Accept both Python list and KojunArray
        if isinstance(arglist, KojunArray):
            args = arglist.elements
        elif isinstance(arglist, list):
            args = arglist
        else:
            raise KojunFunctionError(
                self.name, "Second argument to apply must be an array."
            )
        if not hasattr(func, "call"):
            raise KojunFunctionError(
                self.name, "First argument to apply must be a function."
            )
        return func.call(interpreter, args)

    def arity(self):
        return 2

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionArray:
    def __init__(self):
        self.name: str = "array"

    def call(self, interpreter, arguments):
        if len(arguments) != 2:
            raise KojunFunctionError(
                self.name, f"Expected 2 arguments but got {len(arguments)}."
            )
        init_val, size = arguments
        if not isinstance(size, float) or not size.is_integer() or size < 0:
            raise KojunFunctionError(
                self.name, "Second argument to array must be a non-negative integer."
            )
        return KojunArray([init_val] * int(size), None)

    def arity(self):
        return 2

    def __str__(self):
        return f"<native function {self.name}>"


class NativeFunctionLength:
    def __init__(self):
        self.name: str = "length"

    def call(self, interpreter, arguments):
        if len(arguments) != 1:
            raise KojunFunctionError(
                self.name, f"Expected 1 argument but got {len(arguments)}."
            )
        array_obj = arguments[0]
        if not isinstance(array_obj, KojunArray):
            raise KojunFunctionError(self.name, "Argument to length must be an array.")
        return float(len(array_obj))

    def arity(self):
        return 1

    def __str__(self):
        return f"<native function {self.name}>"


def register_natives(environment):
    natives = [
        NativeFunctionDisplay(),
        NativeFunctionRead(),
        NativeFunctionNewline(),
        NativeFunctionToNumber(),
        NativeFunctionToString(),
        NativeFunctionType(),
        NativeFunctionApply(),
        NativeFunctionArray(),
        NativeFunctionLength(),
    ]
    for native in natives:
        environment.define(native.name, native)


def stringify(obj):
    if obj is None:
        return "nil"
    if isinstance(obj, float):
        text = str(obj)
        if text.endswith(".0"):
            text = text[:-2]
        return text
    if isinstance(obj, bool):
        return str(obj).lower()
    return str(obj)
