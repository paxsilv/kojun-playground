import sys

from src.error import ErrorReporter
from src.interpreter import Interpreter
from src.lexer import Lexer
from src.parser import Parser


class Kojun:
    _reporter = ErrorReporter()
    _interpreter = Interpreter(_reporter)

    @staticmethod
    def main(args):
        if len(args) > 1:
            print("Usage: kojun [script]")
            sys.exit(64)
        elif len(args) == 1:
            Kojun._run_file(args[0])
        else:
            Kojun._run_prompt()

    @staticmethod
    def _run_file(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                source = f.read()
            Kojun._run(source)
            if Kojun._reporter.had_error:
                sys.exit(65)
            if Kojun._reporter.had_runtime_error:
                sys.exit(70)
        except OSError as e:
            Kojun._reporter.report(0, "", f"Could not read file: {e}")
            sys.exit(66)

    @staticmethod
    def _run_prompt():
        try:
            while True:
                line = input("> ")
                if line is None:
                    break
                Kojun._run(line)
                Kojun._reporter.had_error = False
        except (EOFError, KeyboardInterrupt):
            print()
            print("Good bye!")

    @staticmethod
    def _run(source):
        tokens = Lexer(source, Kojun._reporter).scan_tokens()
        statements = Parser(tokens, Kojun._reporter).parse()

        # Stop if there was a syntax error.
        if Kojun._reporter.had_error:
            return

        Kojun._interpreter.interpret(statements)


if __name__ == "__main__":
    Kojun.main(sys.argv[1:])
