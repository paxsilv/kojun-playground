from src.ast import expr, stmt
from src.callables import KojunFunction, Return, register_natives
from src.error import KojunFunctionError, KojunRuntimeError
from src.tokens import TokenType as T
from src.environment import Environment
from src.values import KojunArray


class Interpreter:
    def __init__(self, error_reporter):
        self._globals = Environment()
        self._environment = self._globals
        register_natives(self._globals)
        self._reporter = error_reporter
        self._dispatch_table = self._init_dispatch_table()

    def interpret(self, statements):
        try:
            for statement in statements:
                self._execute(statement)
        except KojunRuntimeError as error:
            self._reporter.runtime_error(error)

    def _init_dispatch_table(self):
        def eval_literal(expression):
            return expression.value

        def eval_logical(expression):
            left = self._evaluate(expression.left)
            match expression.operator.type:
                case T.OR:
                    if self._is_truthy(left):
                        return left
                case T.AND:
                    if not self._is_truthy(left):
                        return left
            return self._evaluate(expression.right)

        def eval_grouping(expression):
            return self._evaluate(expression.expression)

        def eval_unary(expression):
            right = self._evaluate(expression.right)
            match expression.operator.type:
                case T.BANG:
                    return not self._is_truthy(right)
                case T.MINUS:
                    self._check_number_operand(expression.operator, right)
                    return -float(right)

        def eval_binary(expression):
            left = self._evaluate(expression.left)
            right = self._evaluate(expression.right)
            operator = expression.operator
            match operator.type:
                case T.GREATER:
                    self._check_number_operand(operator, left, right)
                    return float(left) > float(right)
                case T.GREATER_EQUAL:
                    self._check_number_operand(operator, left, right)
                    return float(left) >= float(right)
                case T.LESS:
                    self._check_number_operand(operator, left, right)
                    return float(left) < float(right)
                case T.LESS_EQUAL:
                    self._check_number_operand(operator, left, right)
                    return float(left) <= float(right)
                case T.BANG_EQUAL:
                    return not self._is_equal(left, right)
                case T.EQUAL_EQUAL:
                    return self._is_equal(left, right)
                case T.MINUS:
                    self._check_number_operand(operator, left, right)
                    return float(left) - float(right)
                case T.PLUS:
                    if isinstance(left, float) and isinstance(right, float):
                        return float(left) + float(right)
                    if isinstance(left, str) and isinstance(right, str):
                        return str(left) + str(right)
                    raise KojunRuntimeError(
                        operator, "Operands must be two numbers or two strings."
                    )
                case T.SLASH:
                    self._check_number_operand(operator, left, right)
                    return float(left) / float(right)
                case T.STAR:
                    self._check_number_operand(operator, left, right)
                    return float(left) * float(right)
                case T.MODULO:
                    self._check_number_operand(operator, left, right)
                    return float(left) % float(right)

        def eval_call(expression):
            callee = self._evaluate(expression.callee)
            arguments = []
            for arg, is_spread in expression.arguments:
                value = self._evaluate(arg)
                if is_spread:
                    # Accept both KojunArray and Python list
                    if isinstance(value, KojunArray):
                        arguments.extend(value.elements)
                    elif isinstance(value, list):
                        arguments.extend(value)
                    else:
                        raise KojunRuntimeError(
                            expression.paren, "Can only spread arrays."
                        )
                else:
                    arguments.append(value)
            if not hasattr(callee, "call"):
                raise KojunRuntimeError(expression.paren, "Can only call functions.")
            if hasattr(callee, "arity"):
                if callee.arity() is not None and len(arguments) != callee.arity():
                    raise KojunRuntimeError(
                        expression.paren,
                        f"Expected {callee.arity()} arguments but got {len(arguments)}.",
                    )
            try:
                return callee.call(self, arguments)
            except KojunFunctionError as err:
                raise KojunRuntimeError(
                    expression.paren,
                    f"Error in function {err.function}: {err.message}.",
                )

        def eval_variable(expression):
            return self._environment.get(expression.name)

        def eval_assign(expression):
            value = self._evaluate(expression.value)
            self._environment.assign(expression.name, value)
            return value

        def eval_function(expression):
            return KojunFunction(expression, self._environment)

        def eval_if(expression):
            if self._is_truthy(self._evaluate(expression.condition)):
                return self._evaluate(expression.then_branch)
            for condition, then_branch in expression.elif_branches:
                if self._is_truthy(self._evaluate(condition)):
                    return self._evaluate(then_branch)
            if expression.else_branch is not None:
                return self._evaluate(expression.else_branch)
            return None

        def exec_expression(statement):
            self._evaluate(statement.expression)

        def exec_if(statement):
            if self._is_truthy(self._evaluate(statement.condition)):
                self._execute(statement.then_branch)
                return
            for condition, block in statement.elif_branches:
                if self._is_truthy(self._evaluate(condition)):
                    self._execute(block)
                    return
            if statement.else_branch != None:
                self._execute(statement.else_branch)

        def exec_return(statement):
            value = None
            if statement.value != None:
                value = self._evaluate(statement.value)
            raise Return(value)

        def exec_var(statement):
            value = None
            if statement.initializer != None:
                value = self._evaluate(statement.initializer)
            self._environment.define(statement.name.lexeme, value, statement.mutable)

        def exec_while(statement):
            while self._is_truthy(self._evaluate(statement.condition)):
                self._execute(statement.body)

        def exec_block(statement):
            environment = Environment(self._environment)
            self.execute_block(statement.statements, environment)

        def eval_array(expression):
            return KojunArray(
                [self._evaluate(e) for e in expression.elements],
                expression.left_bracket,
            )

        def eval_index(expression):
            collection = self._evaluate(expression.collection)
            index = self._evaluate(expression.index)
            token = expression.left_bracket
            if isinstance(collection, KojunArray):
                if not isinstance(index, float) or not index.is_integer():
                    raise KojunRuntimeError(token, "Array index must be an integer.")
                try:
                    return collection[int(index)]
                except KojunRuntimeError as e:
                    raise KojunRuntimeError(token, e.message)
            raise KojunRuntimeError(token, "Can only index arrays.")

        def eval_index_assign(expression):
            collection = self._evaluate(expression.collection)
            index = self._evaluate(expression.index)
            value = self._evaluate(expression.value)
            token = expression.left_bracket
            op = expression.op
            # Only support assignment to KojunArray
            if not isinstance(collection, KojunArray):
                raise KojunRuntimeError(token, "Can only assign to array indices.")
            if not isinstance(index, float) or not index.is_integer():
                raise KojunRuntimeError(token, "Array index must be an integer.")
            idx = int(index)
            if idx < 0 or idx >= len(collection):
                raise KojunRuntimeError(token, f"Array index {idx} out of bounds.")
            # Support compound assignment (+=, -=, etc.)
            if op.type == T.EQUAL:
                collection.elements[idx] = value
            else:
                # Evaluate compound assignment
                current = collection.elements[idx]
                if op.type == T.PLUS_EQUAL:
                    collection.elements[idx] = current + value
                elif op.type == T.MINUS_EQUAL:
                    collection.elements[idx] = current - value
                elif op.type == T.STAR_EQUAL:
                    collection.elements[idx] = current * value
                elif op.type == T.SLASH_EQUAL:
                    collection.elements[idx] = current / value
                elif op.type == T.MODULO_EQUAL:
                    collection.elements[idx] = current % value
                else:
                    raise KojunRuntimeError(
                        token, "Unsupported assignment operator for array index."
                    )
            return value

        return {
            "evaluate": {
                expr.Literal: eval_literal,
                expr.Logical: eval_logical,
                expr.Grouping: eval_grouping,
                expr.Unary: eval_unary,
                expr.Binary: eval_binary,
                expr.Call: eval_call,
                expr.Variable: eval_variable,
                expr.Assign: eval_assign,
                expr.Function: eval_function,
                expr.If: eval_if,
                expr.Array: eval_array,
                expr.Index: eval_index,
                expr.IndexAssign: eval_index_assign,
            },
            "execute": {
                stmt.Expression: exec_expression,
                stmt.If: exec_if,
                stmt.Return: exec_return,
                stmt.Var: exec_var,
                stmt.While: exec_while,
                stmt.Block: exec_block,
            },
        }

    def _evaluate(self, expression):
        expr_type = type(expression)
        return self._dispatch_table["evaluate"][expr_type](expression)

    def _execute(self, statement):
        stmt_type = type(statement)
        self._dispatch_table["execute"][stmt_type](statement)

    def execute_block(self, statements, environment):
        previous = self._environment
        try:
            self._environment = environment
            for statement in statements:
                self._execute(statement)
        finally:
            self._environment = previous

    def _is_truthy(self, object):
        if object == None:
            return False
        if isinstance(object, bool):
            return bool(object)
        return True

    def _is_equal(self, a, b):
        if a == None and b == None:
            return True
        if a == None:
            return False
        return a == b

    def _check_number_operand(self, operator, *operands):
        for operand in operands:
            if not isinstance(operand, float):
                raise KojunRuntimeError(operator, "Operands must be numbers.")
