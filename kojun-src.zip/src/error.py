import sys

from src.tokens import TokenType


class ErrorReporter:
    had_error = False
    had_runtime_error = False

    @staticmethod
    def error(line, message):
        ErrorReporter.report(line, "", message)

    @staticmethod
    def report(line, where, message):
        print(f"[line {line}] Error{where}: {message}", file=sys.stderr)
        ErrorReporter.had_error = True

    @staticmethod
    def error(token, message):
        if token.type == TokenType.EOF:
            ErrorReporter.report(token.line, " at end", message)
        else:
            ErrorReporter.report(token.line, f" at '{token.lexeme}'", message)

    @staticmethod
    def runtime_error(error):
        print(f"{error.message}\n[line {error.token.line}]", file=sys.stderr)
        ErrorReporter.had_runtime_error = True


class KojunRuntimeError(Exception):
    def __init__(self, token, message):
        super().__init__(message)
        self.token = token
        self.message = message


class KojunFunctionError(Exception):
    def __init__(self, name, message):
        super().__init__()
        self.function = name
        self.message = message
