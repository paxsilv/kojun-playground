from src.tokens import Token, TokenType as T


class Lexer:
    _keywords = {
        "and": T.AND,
        "class": T.CLASS,
        "else": T.ELSE,
        "false": T.FALSE,
        "for": T.FOR,
        "fun": T.FUN,
        "if": T.IF,
        "in": T.IN,
        "let": T.LET,
        "nil": T.NIL,
        "or": T.OR,
        "return": T.RETURN,
        "self": T.SELF,
        "super": T.SUPER,
        "true": T.TRUE,
        "var": T.VAR,
        "while": T.WHILE,
    }

    def __init__(self, source, error_reporter):
        self._reporter = error_reporter
        self._source = source
        self._tokens = []
        self._start = 0
        self._current = 0
        self._line = 1

    def scan_tokens(self):
        while not self._is_at_end():
            self._start = self._current
            self._scan_token()
        self._tokens.append(Token(T.EOF, "", None, self._line))
        return self._tokens

    def _scan_token(self):
        c = self._advance()
        match c:
            case "(":
                self._add_token(T.LEFT_PAREN)
            case ")":
                self._add_token(T.RIGHT_PAREN)
            case "[":
                self._add_token(T.LEFT_BRACKET)
            case "]":
                self._add_token(T.RIGHT_BRACKET)
            case "{":
                self._add_token(T.LEFT_BRACE)
            case "}":
                self._add_token(T.RIGHT_BRACE)
            case ":":
                self._add_token(T.COLON)
            case ",":
                self._add_token(T.COMMA)
            case ";":
                self._add_token(T.SEMICOLON)
            case ".":
                self._add_token(T.DOT_DOT if self._match(".") else T.DOT)
            case "-":
                self._add_token(T.MINUS_EQUAL if self._match("=") else T.MINUS)
            case "+":
                self._add_token(T.PLUS_EQUAL if self._match("=") else T.PLUS)
            case "*":
                self._add_token(T.STAR_EQUAL if self._match("=") else T.STAR)
            case "!":
                self._add_token(T.BANG_EQUAL if self._match("=") else T.BANG)
            case "=":
                self._add_token(T.EQUAL_EQUAL if self._match("=") else T.EQUAL)
            case "<":
                self._add_token(T.LESS_EQUAL if self._match("=") else T.LESS)
            case ">":
                token_type = T.GREATER_EQUAL if self._match("=") else T.GREATER
                self._add_token(token_type)
            case "/":
                if self._match("/"):
                    while self._peek() != "\n" and not self._is_at_end():
                        self._advance()
                elif self._match("="):
                    self._add_token(T.SLASH_EQUAL)
                else:
                    self._add_token(T.SLASH)
            case "%":
                self._add_token(T.MODULO_EQUAL if self._match("=") else T.MODULO)
            case "\n":
                self._line += 1
            case '"':
                self._string()
            case _:
                if c in {" ", "\r", "\t"}:
                    pass
                elif c.isdigit():
                    self._number()
                elif self._is_alpha(c):
                    self._identifier()
                else:
                    self._reporter.error(self._line, "Unexpected character.")

    def _string(self):
        while self._peek() != '"' and not self._is_at_end():
            if self._peek() == "\n":
                self._line += 1
            self._advance()
        if self._is_at_end():
            self._reporter.error(self._line, "Unterminated string.")
            return
        self._advance()
        value = self._source[self._start + 1 : self._current - 1]
        self._add_token(T.STRING, literal=value)

    def _number(self):
        while self._peek().isdigit():
            self._advance()
        if self._peek() == "." and self._peek_next().isdigit():
            self._advance()
            while self._peek().isdigit():
                self._advance()
        value = float(self._source[self._start : self._current])
        self._add_token(T.NUMBER, literal=value)

    def _identifier(self):
        while self._is_alphanum(self._peek()):
            self._advance()
        text = self._source[self._start : self._current]
        token_type = self._keywords.get(text, T.IDENTIFIER)
        if token_type == T.IF and len(self._tokens) > 0:
            if self._tokens[-1].type == T.ELSE:
                self._tokens[-1] = Token(T.ELIF, "else if", None, self._line)
                return
        self._add_token(token_type)

    def _is_alpha(self, c):
        return c == "_" or c.isalpha()

    def _is_alphanum(self, c):
        return self._is_alpha(c) or c.isdigit()

    def _match(self, expected):
        if self._is_at_end() or self._source[self._current] != expected:
            return False
        self._current += 1
        return True

    def _peek(self):
        if self._is_at_end():
            return "\0"
        return self._source[self._current]

    def _peek_next(self):
        if self._current + 1 >= len(self._source):
            return "\0"
        return self._source[self._current + 1]

    def _advance(self):
        c = self._source[self._current]
        self._current += 1
        return c

    def _is_at_end(self):
        return self._current >= len(self._source)

    def _add_token(self, token_type, lexeme=None, literal=None):
        text = lexeme if lexeme else self._source[self._start : self._current]
        self._tokens.append(Token(token_type, text, literal, self._line))
