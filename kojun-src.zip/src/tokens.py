from dataclasses import dataclass
from enum import Enum, auto


class TokenType(Enum):
    # Literals.
    IDENTIFIER = auto()
    NUMBER = auto()
    STRING = auto()

    # Keywords.
    AND = auto()
    CLASS = auto()
    ELSE = auto()
    FALSE = auto()
    FOR = auto()
    FUN = auto()
    IF = auto()
    IN = auto()
    LET = auto()
    NIL = auto()
    OR = auto()
    RETURN = auto()
    SELF = auto()
    SUPER = auto()
    TRUE = auto()
    VAR = auto()
    WHILE = auto()

    # Single-character tokens.
    LEFT_PAREN = auto()
    RIGHT_PAREN = auto()
    LEFT_BRACE = auto()
    RIGHT_BRACE = auto()
    LEFT_BRACKET = auto()
    RIGHT_BRACKET = auto()
    COLON = auto()
    COMMA = auto()
    SEMICOLON = auto()
    MINUS = auto()
    PLUS = auto()
    SLASH = auto()
    STAR = auto()
    MODULO = auto()

    # One or two character tokens.
    ARROW = auto()
    BANG = auto()
    BANG_EQUAL = auto()
    DOT = auto()
    DOT_DOT = auto()
    EQUAL = auto()
    EQUAL_EQUAL = auto()
    GREATER = auto()
    GREATER_EQUAL = auto()
    LESS = auto()
    LESS_EQUAL = auto()
    MINUS_EQUAL = auto()
    PLUS_EQUAL = auto()
    SLASH_EQUAL = auto()
    STAR_EQUAL = auto()
    MODULO_EQUAL = auto()

    ELIF = auto()
    EOF = auto()


@dataclass(frozen=True)
class Token:
    type: TokenType
    lexeme: str
    literal: object
    line: int

    def __str__(self):
        return f"{self.type.name} {self.lexeme} {self.literal}"
