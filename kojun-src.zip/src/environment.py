from src.error import KojunRuntimeError


class Environment:
    def __init__(self, enclosing=None):
        self._enclosing = enclosing
        self._values = {}

    def get(self, name):
        lexeme = name.lexeme
        if lexeme in self._values:
            return self._values.get(lexeme)["value"]
        if self._enclosing:
            return self._enclosing.get(name)
        raise KojunRuntimeError(name, f"Undefined variable '{lexeme}'.")

    def assign(self, name, value):
        lexeme = name.lexeme
        if lexeme in self._values:
            if not self._values[lexeme]["mutable"]:
                raise KojunRuntimeError(
                    name, f"Cannot reassign immutable variable '{lexeme}'."
                )
            self._values[lexeme]["value"] = value
            return
        if self._enclosing:
            self._enclosing.assign(name, value)
            return
        raise KojunRuntimeError(name, f"Undefined variable '{lexeme}'.")

    def define(self, name, value, mutable=True):
        self._values[name] = {"value": value, "mutable": mutable}
