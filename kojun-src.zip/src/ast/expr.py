from dataclasses import dataclass

from src.tokens import Token


@dataclass(frozen=True)
class Assign:
    name: Token
    value: any


@dataclass(frozen=True)
class Binary:
    left: any
    operator: Token
    right: any


@dataclass(frozen=True)
class Call:
    callee: any
    paren: Token
    arguments: list


@dataclass(frozen=True)
class Function:
    name: Token
    params: list
    body: list
    variadic: bool = False
    rest_param: Token = None


@dataclass(frozen=True)
class Grouping:
    expression: any


@dataclass(frozen=True)
class If:
    condition: any
    then_branch: any
    elif_branches: list
    else_branch: any


@dataclass(frozen=True)
class Literal:
    value: any


@dataclass(frozen=True)
class Logical:
    left: any
    operator: Token
    right: any


@dataclass(frozen=True)
class Unary:
    operator: Token
    right: any


@dataclass(frozen=True)
class Variable:
    name: Token


@dataclass(frozen=True)
class Array:
    left_bracket: Token
    elements: list


@dataclass(frozen=True)
class Index:
    left_bracket: Token
    collection: any
    index: any


@dataclass(frozen=True)
class IndexAssign:
    left_bracket: Token
    collection: any
    index: any
    value: any
    op: Token  # assignment operator (e.g., =, +=)
