from dataclasses import dataclass

from src.tokens import Token


@dataclass(frozen=True)
class Block:
    statements: list


@dataclass(frozen=True)
class Expression:
    expression: any


@dataclass(frozen=True)
class If:
    condition: any
    then_branch: any
    elif_branches: list
    else_branch: any


@dataclass(frozen=True)
class Return:
    keyword: Token
    value: any


@dataclass(frozen=True)
class Var:
    name: Token
    initializer: any
    mutable: bool


@dataclass(frozen=True)
class While:
    condition: any
    body: any
