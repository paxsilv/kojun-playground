from src.tokens import Token, TokenType as T
from src.ast import stmt, expr


class Parser:
    class _ParseError(RuntimeError):
        pass

    def __init__(self, tokens, error_reporter):
        self._reporter = error_reporter
        self._tokens = tokens
        self._current = 0

    def parse(self):
        statements = []
        while not self._is_at_end():
            statements.append(self._declaration())
        return statements

    def _expression(self):
        return self._assignment()

    def _declaration(self):
        try:
            if self._check(T.FUN) and self._peek_next().type != T.LEFT_PAREN:
                return self._function_declaration()
            if self._match(T.VAR):
                return self._var_declaration(mutable=True)
            if self._match(T.LET):
                return self._var_declaration(mutable=False)
            return self._statement()
        except self._ParseError:
            self._synchronize()
            return None

    def _statement(self):
        if self._match(T.IF):
            return self._if_statement()
        if self._match(T.RETURN):
            return self._return_statement()
        if self._match(T.WHILE):
            return self._while_statement()
        return self._expression_statement()

    def _if_statement(self):
        self._match(T.LEFT_PAREN)
        condition = self._expression()
        self._consume(T.COLON, "Expect ':' after condition.")
        then_branch = stmt.Block(self._block({T.RIGHT_PAREN}))
        self._consume(T.RIGHT_PAREN, "Expect ')' after if statement.")
        elif_branches = []
        while self._match(T.ELIF):
            self._match(T.LEFT_PAREN)
            elif_condition = self._expression()
            self._consume(T.COLON, "Expect ':' after condition.")
            elif_block = stmt.Block(self._block({T.RIGHT_PAREN}))
            self._consume(T.RIGHT_PAREN, "Expect ')' after else if statement.")
            elif_branches.append((elif_condition, elif_block))
        else_branch = None
        if self._match(T.ELSE):
            self._match(T.LEFT_PAREN)
            self._consume(T.COLON, "Expect ':' after 'else'.")
            else_branch = stmt.Block(self._block({T.RIGHT_PAREN}))
            self._consume(T.RIGHT_PAREN, "Expect ')' after if statement.")
        return stmt.If(condition, then_branch, elif_branches, else_branch)

    def _if_expression(self):
        self._match(T.LEFT_PAREN)
        condition = self._expression()
        self._consume(T.COLON, "Expect ':' after condition.")
        then_branch = self._expression()
        self._consume(T.RIGHT_PAREN, "Expect ')' after if expression.")
        if self._peek_next().type in {T.ELIF, T.ELSE}:
            self._match(T.SEMICOLON)
        elif_branches = []
        while self._match(T.ELIF):
            self._match(T.LEFT_PAREN)
            elif_condition = self._expression()
            self._consume(T.COLON, "Expect ':' after condition.")
            elif_then = self._expression()
            self._consume(T.RIGHT_PAREN, "Expect ')' after else if expression.")
            if self._peek_next().type in {T.ELIF, T.ELSE}:
                self._match(T.SEMICOLON)
            elif_branches.append((elif_condition, elif_then))
        else_branch = None
        if self._match(T.ELSE):
            self._match(T.LEFT_PAREN)
            self._consume(T.COLON, "Expect ':' after 'else'.")
            self._match(T.SEMICOLON)
            else_branch = self._expression()
            self._consume(T.RIGHT_PAREN, "Expect ')' after else expression.")
            if self._peek_next().type in {T.ELIF, T.ELSE}:
                self._match(T.SEMICOLON)
        return expr.If(condition, then_branch, elif_branches, else_branch)

    def _return_statement(self):
        keyword = self._previous()
        value = None
        if not self._check(T.SEMICOLON) and not self._check(T.RIGHT_PAREN):
            value = self._expression()
        if not self._check(T.RIGHT_PAREN):
            self._consume(T.SEMICOLON, "Expect ';' after return value.")
        return stmt.Return(keyword, value)

    def _function_declaration(self):
        self._match(T.FUN)
        name = self._consume(T.IDENTIFIER, "Expect function name.")
        function = self._function(name)
        self._match(T.SEMICOLON)
        return stmt.Var(name, function, mutable=True)

    def _var_declaration(self, mutable=True):
        name = self._consume(T.IDENTIFIER, "Expect variable name.")
        initializer = None
        if self._match(T.EQUAL):
            initializer = self._expression()
        elif not mutable:
            self._reporter.error(
                name, "Immutable 'let' declarations must have an initializer."
            )
        if not self._check(T.RIGHT_PAREN):
            self._consume(T.SEMICOLON, "Expect ';' after variable declaration.")
        return stmt.Var(name, initializer, mutable)

    def _while_statement(self):
        self._match(T.LEFT_PAREN)
        condition = self._expression()
        self._consume(T.COLON, "Expect ':' after condition.")
        body = stmt.Block(self._block({T.RIGHT_PAREN}))
        self._consume(T.RIGHT_PAREN, "Expect ')' after while statement.")
        return stmt.While(condition, body)

    def _expression_statement(self):
        expression = self._expression()
        if not self._check_any({T.ELIF, T.ELSE, T.RIGHT_PAREN}):
            self._consume(T.SEMICOLON, "Expect ';' after expression.")
        return stmt.Expression(expression)

    def _function(self, name=None):
        parameters, variadic, rest_param = self._parameter_list()
        self._consume(T.COLON, "Expect ':' before function body.")
        body = self._block({T.RIGHT_PAREN})
        self._consume(T.RIGHT_PAREN, "Expect ')' after function body.")

        # Implicit return for single expression
        if len(body) == 1 and isinstance(body[0], stmt.Expression):
            line = self._previous().line
            return_token = Token(T.RETURN, "return", None, line)
            body = [stmt.Return(return_token, body[0].expression)]
        # Implicit return for single if-statement with all branches as single-expression blocks
        elif len(body) == 1 and isinstance(body[0], stmt.If):
            if_stmt = body[0]

            def block_to_expr(block):
                # Accepts stmt.Block with a single stmt.Expression
                if (
                    isinstance(block, stmt.Block)
                    and len(block.statements) == 1
                    and isinstance(block.statements[0], stmt.Expression)
                ):
                    return block.statements[0].expression
                return None

            then_expr = block_to_expr(if_stmt.then_branch)
            elif_exprs = []
            for cond, branch in if_stmt.elif_branches:
                expr_branch = block_to_expr(branch)
                if expr_branch is None:
                    break
                elif_exprs.append((cond, expr_branch))
            else_expr = (
                block_to_expr(if_stmt.else_branch) if if_stmt.else_branch else None
            )

            # Only if all branches are single-expression blocks
            if (
                then_expr is not None
                and len(elif_exprs) == len(if_stmt.elif_branches)
                and (if_stmt.else_branch is None or else_expr is not None)
            ):
                line = self._previous().line
                return_token = Token(T.RETURN, "return", None, line)
                if_expr = expr.If(
                    if_stmt.condition,
                    then_expr,
                    elif_exprs,
                    else_expr,
                )
                body = [stmt.Return(return_token, if_expr)]

        return expr.Function(name, parameters, body, variadic, rest_param)

    def _parameter_list(self):
        self._consume(T.LEFT_PAREN, "Expect '(' after function name.")
        parameters = []
        variadic = False
        rest_param = None
        if not self._check(T.COLON):
            while True:
                if len(parameters) >= 255:
                    self._error(self._peek(), "Can't have more than 255 parameters.")
                if self._match(T.DOT_DOT):
                    variadic = True
                    rest_param = self._consume(
                        T.IDENTIFIER, "Expect variadic parameter name."
                    )
                    break
                parameters.append(self._consume(T.IDENTIFIER, "Expect parameter name."))
                if not self._match(T.COMMA):
                    break
        return parameters, variadic, rest_param

    def _block(self, stop_tokens):
        statements = []
        while not self._check_any(stop_tokens) and not self._is_at_end():
            statements.append(self._declaration())
        return statements

    def _assignment(self):
        expression = self._or()
        if self._match(
            T.EQUAL,
            T.PLUS_EQUAL,
            T.MINUS_EQUAL,
            T.STAR_EQUAL,
            T.SLASH_EQUAL,
            T.MODULO_EQUAL,
        ):
            op = self._previous()
            value = self._assignment()
            # Support assignment to variables and to indexed arrays
            if isinstance(expression, expr.Variable):
                name = expression.name
                if op.type == T.EQUAL:
                    return expr.Assign(name, value)
                op_type = {
                    T.PLUS_EQUAL: T.PLUS,
                    T.MINUS_EQUAL: T.MINUS,
                    T.STAR_EQUAL: T.STAR,
                    T.SLASH_EQUAL: T.SLASH,
                    T.MODULO_EQUAL: T.MODULO,
                }[op.type]
                op_token = Token(op_type, op.lexeme[:-1], None, op.line)
                binary = expr.Binary(expression, op_token, value)
                return expr.Assign(name, binary)
            elif isinstance(expression, expr.Index):
                # Assignment to array index: x[0] = 2
                # Create a new AST node for index assignment
                return expr.IndexAssign(
                    expression.left_bracket,
                    expression.collection,
                    expression.index,
                    value,
                    op,
                )
            self._error(op, "Invalid assignment target.")
        return expression

    def _or(self):
        expression = self._and()
        while self._match(T.OR):
            operator = self._previous()
            right = self._and()
            expression = expr.Logical(expression, operator, right)
        return expression

    def _and(self):
        expression = self._equality()
        while self._match(T.AND):
            operator = self._previous()
            right = self._equality()
            expression = expr.Logical(expression, operator, right)
        return expression

    def _equality(self):
        expression = self._comparison()
        while self._match(T.BANG_EQUAL, T.EQUAL_EQUAL):
            operator = self._previous()
            right = self._comparison()
            expression = expr.Binary(expression, operator, right)
        return expression

    def _comparison(self):
        expression = self._term()
        while self._match(T.GREATER, T.GREATER_EQUAL, T.LESS, T.LESS_EQUAL):
            operator = self._previous()
            right = self._term()
            expression = expr.Binary(expression, operator, right)
        return expression

    def _term(self):
        expression = self._factor()
        while self._match(T.MINUS, T.PLUS):
            operator = self._previous()
            right = self._factor()
            expression = expr.Binary(expression, operator, right)
        return expression

    def _factor(self):
        expression = self._unary()
        while self._match(T.SLASH, T.STAR, T.MODULO):
            operator = self._previous()
            right = self._unary()
            expression = expr.Binary(expression, operator, right)
        return expression

    def _unary(self):
        if self._match(T.BANG, T.MINUS):
            operator = self._previous()
            right = self._unary()
            return expr.Unary(operator, right)
        return self._call()

    def _call(self):
        expression = self._primary()
        while True:
            if self._match(T.LEFT_PAREN):
                expression = self._finish_call(expression)
            elif self._match(T.LEFT_BRACKET):
                left_bracket = self._previous()
                index = self._expression()
                self._consume(T.RIGHT_BRACKET, "Expect ']' after index.")
                expression = expr.Index(left_bracket, expression, index)
            else:
                break
        return expression

    def _finish_call(self, callee):
        arguments = []
        if not self._check(T.RIGHT_PAREN):
            while True:
                is_spread = False
                if self._match(T.DOT_DOT):
                    is_spread = True
                arguments.append((self._expression(), is_spread))
                if not self._match(T.COMMA):
                    break
        paren = self._consume(T.RIGHT_PAREN, "Expect ')' after arguments.")
        return expr.Call(callee, paren, arguments)

    def _primary(self):
        if self._match(T.FUN):
            return self._function()
        if self._match(T.IF):
            return self._if_expression()
        if self._match(T.FALSE):
            return expr.Literal(False)
        if self._match(T.TRUE):
            return expr.Literal(True)
        if self._match(T.NIL):
            return expr.Literal(None)
        if self._match(T.NUMBER, T.STRING):
            return expr.Literal(self._previous().literal)
        if self._match(T.IDENTIFIER):
            return expr.Variable(self._previous())
        if self._match(T.LEFT_BRACE):
            expression = self._expression()
            self._consume(T.RIGHT_BRACE, "Expect '}' after expression.")
            return expr.Grouping(expression)
        if self._match(T.LEFT_BRACKET):
            left_bracket = self._previous()
            elements = []
            if not self._check(T.RIGHT_BRACKET):
                while True:
                    elements.append(self._expression())
                    if not self._match(T.COMMA):
                        break
            self._consume(T.RIGHT_BRACKET, "Expect ']' after array elements.")
            return expr.Array(left_bracket, elements)
        raise self._error(self._peek(), "Expect expression.")

    def _match(self, *types):
        for type in types:
            if self._check(type):
                self._advance()
                return True
        return False

    def _consume(self, type, message):
        if self._check(type):
            return self._advance()
        raise self._error(self._peek(), message)

    def _check(self, type):
        if self._is_at_end():
            return False
        return self._peek().type == type

    def _check_any(self, token_types):
        if self._is_at_end():
            return False
        return self._peek().type in token_types

    def _advance(self):
        if not self._is_at_end():
            self._current += 1
        return self._previous()

    def _is_at_end(self):
        return self._peek().type == T.EOF

    def _peek(self):
        return self._tokens[self._current]

    def _peek_next(self):
        return self._tokens[self._current + 1]

    def _previous(self):
        return self._tokens[self._current - 1]

    def _error(self, token, message):
        self._reporter.error(token, message)
        return self._ParseError()

    def _synchronize(self):
        self._advance()
        while not self._is_at_end():
            if self._previous().type in {T.SEMICOLON, T.RIGHT_PAREN}:
                return
            if self._peek().type in {
                T.CLASS,
                T.FUN,
                T.VAR,
                T.FOR,
                T.IF,
                T.WHILE,
                T.RETURN,
            }:
                return
            self._advance()
